System.register([], function (_export, _context) {
  return {
    execute: function() {
      

      /* 
		This is a temporary solution to fix BDS system js error.
		The system.js should be handled as part of BDS/stencil build.
	  
       */
      
    }
  }
})